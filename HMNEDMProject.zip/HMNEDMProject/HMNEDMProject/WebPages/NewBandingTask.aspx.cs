﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HMNEDMProject.WebPages
{
    public partial class NewBandingTask : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            String userFName = (String)Session["UserName"];
            PMWelcomeLabel.Text = "Welcome " + userFName + "!";

            HMNEDMProject.Common.DatabaseConnection dc = new HMNEDMProject.Common.DatabaseConnection();
            String currSessID = (String)Session["sessID"];
            String currTaskID = dc.getTaskID(currSessID, "banding");

            DataTable dt = new DataTable();
            // Banding Details
            dt = dc.selectQuery("select * from hummingbird where BTASKID = '" + currTaskID + "' ");
            GVBandingTask.DataSource = dt;
            GVBandingTask.DataBind();
        }
        protected void lBtnPMLogout_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("Login.aspx", false);
        }

        protected void EnterBandingDetails_Click(object sender, EventArgs e)
        {
            HMNEDMProject.Common.DatabaseConnection dc = new Common.DatabaseConnection();
            String task_hr, task_min, task_dn, HTime;

            task_hr = HTimeHourList.SelectedValue;
            task_min = HTimeMinList.SelectedValue;
            task_dn = HTimeampmList.SelectedValue;

            HTime = dc.CalculateTime(task_hr, task_min, task_dn);

            String HBandStatus, HBandNumber, HTarsus, HSize, HSpecies, HSex, HOldBandNumber, HGorColor,
                HHeadGCount, HGrooves, HBuffy, HPriWidth, HWingTail, HTailCent, HTailMid, HTailOut, HTailMeas, HWingCd,
                HCulmen, HPollenColor, HPollenLocation, HFat, HCPBreed, HGorget, HHeadMolt, HBodyMolt, HPrimMolt, HSecMolt, HTailMolt,
                HFeatherCollected, HDayRecap, HPhotosTaken, HSampleCollected, HComment, HNonIridescentColor,
                HBirdRecordID, HBandingTime;
            Int32 HAge, HGorCount, HWeight;

            String currSessID = (String)Session["sessID"];

            //
            String HcurrTaskID = dc.getTaskID(currSessID, "banding");

            //Inserting in banding table

            HBandStatus = HBandStatusList.SelectedValue;
            HBandNumber = txtbxHBandNumber.Text;
            HTarsus = txtbxHTarsus.Text;
            HSize = HSizeMaterialList.SelectedValue;
            HSpecies = HBirdSpeciesList.SelectedValue;
            HSex = HSexList.SelectedValue;
            HAge = Int32.Parse(HAgeList.SelectedValue);
            HOldBandNumber = txtbxOldBandNumber.Text;
            HGorColor = HGorColorList.SelectedValue;
            HNonIridescentColor = HNonIridescentColorList.SelectedValue;
            String HtempGor = HGorColor + "/" + HNonIridescentColor;
            HGorColor = HtempGor;
            HGorCount = Int32.Parse(txtbxHGorCount.Text);
            HHeadGCount = txtbxHHeadGCount.Text;
            HGrooves = HGroovesList.SelectedValue.ToString();
            HBuffy = HBuffyList.SelectedValue;
            HPriWidth = HPriWidthList.SelectedValue;
            HWingTail = HWingTailList.SelectedValue;
            HTailCent = txtbxHTailCent.Text;
            HTailMid = txtbxHTailMid.Text;
            HTailOut = txtbxHTailOut.Text;
            HTailMeas = txtbxHTailMeas.Text;
            HWingCd = txtbxHWingCd.Text;
            HCulmen = txtbxHCulmen.Text;
            HPollenColor = HPollenColorList.SelectedValue;
            HPollenLocation = HPollenLocationList.SelectedValue;
            HFat = HFatList.SelectedValue;
            HCPBreed = HCPBreedList.SelectedValue;
            HGorget = txtbxHGorget.Text;
            HHeadMolt = txtbxHHeadMolt.Text;
            HBodyMolt = txtbxHBodyMolt.Text;
            HPrimMolt = txtbxHPrimaryMolt.Text;
            HSecMolt = txtbxHSecondaryMolt.Text;
            HTailMolt = txtbxHTailMolt.Text;
            HWeight = Int32.Parse(txtbxHWeight.Text);
            HFeatherCollected = txtbxHFeatherCollected.Text;            
            HSampleCollected = HSampleList.SelectedValue;
            HDayRecap = txtbxHDayRecap.Text;
            HComment = txtbxHComments.Text;
            HBirdRecordID = "0";
            HBandingTime = HTime;
            HPhotosTaken = HPhotoList.SelectedValue;

            String HLeadBanderID = HMembersList.SelectedValue;
            Int32 HNumBirdsBanded = 1;

            dc.InsertIntoBanding(HcurrTaskID, HLeadBanderID, HNumBirdsBanded); 

            dc.InsertHummingbirdData(HOldBandNumber, HBandNumber,HcurrTaskID, HTarsus, HSize, HSpecies, HSex, HAge, HGorColor,
                HGorCount,HHeadGCount, HGrooves, HBuffy, HPriWidth, HWingTail, HTailCent, HTailMid, HTailOut, HTailMeas, HWingCd,
                HCulmen, HPollenColor, HPollenLocation, HFat, HCPBreed, HGorget, HHeadMolt, HBodyMolt, HPrimMolt, HSecMolt,
                HTailMolt,HWeight, HFeatherCollected, HSampleCollected, HDayRecap, HComment, HBandStatus, HBirdRecordID,
                HBandingTime, HPhotosTaken);

            Response.Redirect("NewBandingTask.aspx");
        }

        protected void ResetBandingData_Click(object sender, EventArgs e)
        {
            Response.Redirect("NewBandingTask.aspx");
        }

        protected void EndBandingTask_Click(object sender, EventArgs e)
        {
            Response.Redirect("NewTaskPage.aspx");
        }
    }
}