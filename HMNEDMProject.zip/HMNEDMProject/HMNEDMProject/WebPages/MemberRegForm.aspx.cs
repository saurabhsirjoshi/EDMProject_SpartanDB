﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HMNEDMProject.WebPages
{
    public partial class MemberRegForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            String userFName = (String)Session["UserName"];
            PMWelcomeLabel.Text = "Welcome " + userFName + "!";
        }
       
        protected void RegNewMem_Click(object sender, EventArgs e)
        {
            HMNEDMProject.Common.DatabaseConnection dc = new Common.DatabaseConnection();
            String MEmailID, MFname, MMname, MLname, MStreet, MCity, MState, Mtype, MPhoneNo, MSSN, MHrlyWage ;

            Mtype = MtypeList.SelectedValue;
            MFname = txtbxMFirstNm.Text;
            MMname = txtbxMmiddleNm.Text;
            MLname = txtbxMlastNm.Text;
            MStreet = txtbxMStreet.Text;
            MCity = txtbxMCity.Text;
            MState = dpMState.SelectedValue;
            MPhoneNo = txtbxMPhone.Text;
            MEmailID = txtbxMEmail.Text;
            MSSN = txtbxSSN.Text;
            MHrlyWage = txtbxHrlyWage.Text;
            dc.InsertNewMemberData(MEmailID, MFname, MMname, MLname, MStreet, MCity, MState, Mtype, MPhoneNo, MSSN, MHrlyWage );

            //Response.Write(<script type="text/JavaScript"> alert('hello world') </script>);
        }

        protected void lBtnPMLogout_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("Login.aspx", false);
        }
        protected void ResetMemData_Click(object sender, EventArgs e)
        {
            Response.Redirect("MemberRegForm.aspx");
        }

        protected void Back_Click(Object sender, EventArgs e)
        {
            Response.Redirect("HMNPermanentMemberHome.aspx");
        }
    }
    }
     