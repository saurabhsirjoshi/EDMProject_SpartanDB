﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HMNEDMProject.WebPages
{
    public partial class SessionManagement : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            String userFName = (String)Session["UserName"];
            PMWelcomeLabel.Text = "Welcome " + userFName + "!";
        }

        protected void lBtnPMLogout_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("Login.aspx", false);
        }

        
        protected void btnAddNewSession_Click(object sender, EventArgs e)
        {
            Response.Redirect("AddNewSession.aspx", false);
        }

        protected void btnSelectSession_Click(object sender, EventArgs e)
        {
            String sessID = txtbxSelectSession.Text.ToString();
            sessID = Regex.Replace(sessID, "[^0-9a-zA-Z]+", "");
            HMNEDMProject.Common.DatabaseConnection dc = new Common.DatabaseConnection();
            //dc.getSessionData(sessID);
            Session["sessID"] = sessID;
            Response.Redirect("CreateEditSession.aspx", false);
        }
    }
}