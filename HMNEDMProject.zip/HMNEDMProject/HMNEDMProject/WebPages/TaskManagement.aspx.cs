﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HMNEDMProject.WebPages
{
    public partial class TaskManagement : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            String userFName = (String)Session["UserName"];
            PMWelcomeLabel.Text = "Welcome " + userFName + "!";

            HMNEDMProject.Common.DatabaseConnection dc = new HMNEDMProject.Common.DatabaseConnection();
            DataTable dt = new DataTable();
            String currSessID;
            currSessID = (String)Session["sessID"];
            String query;
  
            // Task Details
            query = "select * from task where sessionid = '" + currSessID + "' ";
            dt = dc.selectQuery(query);
            lvTasks.DataSource = dt;
            lvTasks.DataBind();
        }

        protected void lBtnPMLogout_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("Login.aspx", false);
        }

        protected void btnAddNewTask_Click(object sender, EventArgs e)
        {
            Response.Redirect("NewtaskPage.aspx", false);
        }

        protected void btnSelectTask_Click(object sender, EventArgs e)
        {
            String taskID = txtbxSelectTask.Text.ToString();
            taskID = Regex.Replace(taskID, "[^0-9a-zA-Z]+", "");
            Session["taskID"] = taskID;

            HMNEDMProject.Common.DatabaseConnection dc = new HMNEDMProject.Common.DatabaseConnection();
            DataTable dt = new DataTable();
            String currSessID;
            currSessID = (String)Session["sessID"];

            // Task Details
            dt = dc.selectQuery("select task_type from task where task_id = '" + taskID + "' ");
            String task_type = "";
            try
            {
                task_type = dt.Rows[0][0].ToString();
            }
            catch(Exception e1)
            {
                Console.WriteLine(e1.StackTrace);
            }

            if (task_type.ToUpper() == "BANDING")
                Response.Redirect("NewBandingTask.aspx", false);
            else if (task_type.ToUpper() == "TRAPPING")
                Response.Redirect("NewTrappingTask.aspx", false);   
            
            /*
            else if (task_type == "OBSERVATION")
                Response.Redirect("NewTaskPage.aspx", false);
            else if (task_type == "MAINTAINENCE")
                Response.Redirect("NewTaskPage.aspx", false);
             */
        }
    
    }
}