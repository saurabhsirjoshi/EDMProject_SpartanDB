﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HMNEDMProject.WebPages
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            btnLogin.Click += new EventHandler(this.btn_submit);
        }
        public void btn_submit(Object sender, EventArgs e)
        {
            HMNEDMProject.Common.DatabaseConnection dc = new Common.DatabaseConnection();
            String userName, passWord, validatorStr;
            String[] returnStrArr;

            userName = loginUName.Text;
            passWord = loginPWord.Text;
            validatorStr = dc.validateUser(userName, passWord);

            if (validatorStr == "-1")
                Response.Redirect("Login.aspx", false);
            else
            {
                returnStrArr = validatorStr.Split('_');
                
                Session["UserName"] = returnStrArr[1];
                Session["UserID"] = returnStrArr[2];

                if (returnStrArr[0] == "2")
                    Response.Redirect("HMNPermanentMemberHome.aspx");
                else if (returnStrArr[0] == "3")
                    Response.Redirect("HMNVolunteerHome.aspx");
            } 
        }
    }
}