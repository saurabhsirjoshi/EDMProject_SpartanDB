﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HMNEDMProject.WebPages
{
    public partial class HMNReports : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            String userFName = (String)Session["UserName"];
            PMWelcomeLabel.Text = "Welcome " + userFName + "!";
        }

        protected void lBtnPMLogout_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("Login.aspx", false);
        }
        protected void btnSelectSession_Click(object sender, EventArgs e)
        {
            String sessID = txtbxSelectSession.Text.ToString();
            sessID = Regex.Replace(sessID, "[^0-9a-zA-Z]+", "");
            HMNEDMProject.Common.DatabaseConnection dc = new Common.DatabaseConnection();

            Session["sessSummaryID"] = sessID;
            dc.generateSessionSummary(sessID);
            dc.generateSessionCounts(sessID);

            Response.Redirect("ViewSessionSummary.aspx", false);
        }

        protected void btnMemberSession_Click(object sender, EventArgs e)
        {
            String sessID = txtbxSelectSession.Text.ToString();
            sessID = Regex.Replace(sessID, "[^0-9a-zA-Z]+", "");

            Session["reportType"] = "A";
            Session["sessSummaryID"] = sessID;
            Session["whereClause"] = Regex.Replace(txtBxMemID.Text.ToString(), "[^0-9a-zA-Z]+", "");
            Session["queryTable"] = "SessionMembersInfo";
            Session["queryField"] = "MEM_ID";

            Response.Redirect("SingleSummaryReport.aspx", false);
        }

        protected void btnSessionMemberInfo_Click(object sender, EventArgs e)
        {
            String sessID = txtbxSelectSession.Text.ToString();
            sessID = Regex.Replace(sessID, "[^0-9a-zA-Z]+", "");

            Session["reportType"] = "A";
            Session["sessSummaryID"] = sessID;
            Session["whereClause"] = sessID;
            Session["queryTable"] = "SessionMembersInfo";
            Session["queryField"] = "SESSIOnID";

            Response.Redirect("SingleSummaryReport.aspx", false);
        }

        protected void btnOutputReport2_Click(object sender, EventArgs e)
        {
            String sessID = txtbxSelectSession.Text.ToString();
            sessID = Regex.Replace(sessID, "[^0-9a-zA-Z]+", "");

            Session["reportType"] = "A";
            Session["sessSummaryID"] = sessID;
            Session["whereClause"] = sessID;
            Session["queryTable"] = "Output2_report";
            Session["queryField"] = "SESSIOnID";

            Response.Redirect("SingleSummaryReport.aspx", false);
        }

        protected void btnSessionReportB_Click(object sender, EventArgs e)
        {
            String sessID = txtbxSelectSession.Text.ToString();
            sessID = Regex.Replace(sessID, "[^0-9a-zA-Z]+", "");

            Session["reportType"] = "A";
            Session["sessSummaryID"] = sessID;
            Session["whereClause"] = sessID;
            Session["queryTable"] = "SessionReportB";
            Session["queryField"] = "SessionID";

            Response.Redirect("SingleSummaryReport.aspx", false);
        }

        protected void btnInvDue_Click(object sender, EventArgs e)
        {
            Session["reportType"] = "B";
            Session["queryTable"] = "InvMaintainDue";
            Response.Redirect("SingleSummaryReport.aspx", false);
        }

        protected void btnMemberEfficiency_Click(object sender, EventArgs e)
        {
            Session["reportType"] = "B";
            Session["queryTable"] = "MEMBEREFFICIENCY";
            Response.Redirect("SingleSummaryReport.aspx", false);
        }
    }
}