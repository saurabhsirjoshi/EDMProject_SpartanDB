﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HMNEDMProject.WebPages
{
    public partial class SingleSummaryReport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            String userFName = (String)Session["UserName"];
            String whereClause = (String)Session["WhereClause"];
            String queryTable = (String)Session["queryTable"];
            String queryField = (String)Session["queryField"];
            String reportType = (String)Session["reportType"];

            PMWelcomeLabel.Text = "Welcome " + userFName + "!";

            HMNEDMProject.Common.DatabaseConnection dc = new HMNEDMProject.Common.DatabaseConnection();
            DataTable dt = new DataTable();
            String currSessID;
            currSessID = (String)Session["sessSummaryID"];

            // Session Details
            if (reportType == "A")
                dt = dc.selectQuery("select * from " + queryTable + " where " + queryField + " = '" + whereClause + "' ");
            else if(reportType=="B")
                dt = dc.selectQuery("select * from " + queryTable);
            gvDynamicTables.DataSource = dt;
            gvDynamicTables.DataBind();
        }

        protected void lBtnPMLogout_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("Login.aspx", false);
        }
    }
}