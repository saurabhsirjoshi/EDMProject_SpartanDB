﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HMNEDMProject.WebPages
{
    public partial class RawData : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            String userFName = (String)Session["UserName"];
            PMWelcomeLabel.Text = "Welcome " + userFName + "!";
        }

        protected void lBtnPMLogout_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("Login.aspx", false);
        }

        protected void btnRunQuery_Click(object sender, EventArgs e)
        {
            string strFromTextArea = txtArQuery.InnerText;        

            HMNEDMProject.Common.DatabaseConnection dc = new HMNEDMProject.Common.DatabaseConnection();
            DataTable dt = new DataTable();
            dt = dc.selectQuery(strFromTextArea);
            gvDynamicTables.DataSource = dt;
            gvDynamicTables.DataBind();
        }
    }
}