﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HMNEDMProject.WebPages
{
    public partial class NewTrappingTask : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            String userFName = (String)Session["UserName"];
            PMWelcomeLabel.Text = "Welcome " + userFName + "!";

            HMNEDMProject.Common.DatabaseConnection dc = new HMNEDMProject.Common.DatabaseConnection();
            String currSessID = (String)Session["sessID"];
            DataTable dt = new DataTable();
            //dt = dc.PopulateSessionData(currSessID);
            dt = dc.selectQuery("select * from sessions where sessionid = '" + currSessID + "' ");
            SessionGrid.DataSource = dt;
            SessionGrid.DataBind();

            String currTaskID = dc.getTaskID(currSessID, "trapping");
            DataTable dt2 = new DataTable();
            dt2 = dc.selectQuery("select * from trapping where ttaskid = '" + currTaskID + "' ");
            TaskGrid.DataSource = dt2;
            TaskGrid.DataBind();

        }

        protected void Storetaskinfobtn_Click(object sender, EventArgs e)
        {
          
            HMNEDMProject.Common.DatabaseConnection dc = new HMNEDMProject.Common.DatabaseConnection();
            String task_hr, task_min, task_dn, task_edtime, task_trpchk;
            Int32 task_EscpCnt, task_HrNo, task_VisitNtcap;
            String currSessID = (String)Session["sessID"];
          
            //Updating Task table with end-time
            String currTaskID = dc.getTaskID(currSessID, "trapping");
            task_hr = dpHrlist.Text;
            task_min = dpMinlist.Text;
            task_dn = dpampm.Text;
           
            task_edtime = dc.CalculateTime(task_hr, task_min, task_dn);
            
            //dc.updateTask(currTaskID, task_edtime);

            //Inserting in trapping table
            task_trpchk = txtbxTrapChk.Text;
            task_EscpCnt = Int32.Parse(txtbxEscapeCnt.Text);
            task_HrNo = Int32.Parse(txtbxHourNo.Text);
            task_VisitNtcap = Int32.Parse(txtbxVisitedNtCap.Text);

            dc.InsertIntoTrapping(currTaskID, task_trpchk, task_EscpCnt, task_HrNo, task_VisitNtcap, task_edtime);

            Response.Redirect("NewTrappingTask.aspx");
        }
        protected void lBtnPMLogout_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("Login.aspx", false);
        }

        protected void EndTrapping_Click(object sender, EventArgs e)
        {
            Response.Redirect("NewTaskPage.aspx");
        }
    }
}