﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HMNEDMProject.WebPages
{
    public partial class LoginSuccess : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            String userFName = (String)Session["UserName"];
            PMWelcomeLabel.Text = "Welcome " + userFName + "!";
        }

        protected void lBtnPMLogout_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("Login.aspx", false);
        }

        protected void btnRegisterMember_Click(object sender, EventArgs e)
        {
            Response.Redirect("MemberRegForm.aspx", false);
        }

        protected void btnCreateNewSession_Click(object sender, EventArgs e)
        {
            Response.Redirect("AddNewSession.aspx", false);
        }
       
    }
}