﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HMNEDMProject.WebPages
{
    public partial class AddNewSession : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            String userFName = (String)Session["UserName"];
            PMWelcomeLabel.Text = "Welcome " + userFName + "!";
        }
        protected void lBtnPMLogout_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("Login.aspx", false);
        }

        protected void btnSubmitNewSession_Click(object sender, EventArgs e)
        {
            DateTime sessDt = clSessDt.SelectedDate;
            String sessDesc = txtbxSessDesc.Text.ToString();
            String teamName = txtbxTeamName.Text.ToString();
            String sessSiteID = "";
            String str = "";

            sessDesc = Regex.Replace(sessDesc, "[^0-9a-zA-Z]+", "");
            
            // Get RadioButton Value
            for (int i = 0; i < GridView1.Rows.Count; i++)
            {
                RadioButton rb = (GridView1.Rows[i].FindControl("rbtnSessLoc") as RadioButton);
                if (rb.Checked == true)
                {
                    sessSiteID = GridView1.Rows[i].Cells[1].Text;
                }
            }

            HMNEDMProject.Common.DatabaseConnection dc = new HMNEDMProject.Common.DatabaseConnection();
            String insertedSessionID = dc.insertIntoSession(sessDesc, sessSiteID, sessDt);
            String newTeamID = dc.insertTeam(insertedSessionID, teamName, sessSiteID);

            // Select the checkboxes from the GridView control
            for (int i = 0; i < gvMembers.Rows.Count; i++)
            {
                GridViewRow row = gvMembers.Rows[i];
                bool isChecked = ((CheckBox)row.FindControl("chkSelect")).Checked;
                if (isChecked)
                {
                    // Column 2 is the name column
                    str = str + (gvMembers.Rows[i].Cells[1].Text) + "_";
                }
            }

            DateTime dt = DateTime.Now;
            //String timeStamp = dc.CalculateTime(dt.Hour.ToString(), dt.Minute.ToString(), "AM");
            String timeStamp = dc.CalculateTime("12", "12", "AM");
            String[] memArr = str.Split('_');
            
            for (int i = 0; i < memArr.Length - 1; i++)
            {
                dc.insertTeamDetails(newTeamID, memArr[i].ToString(), timeStamp, timeStamp);
            }
            
            Response.Redirect("SessionManagement.aspx", false);
        }
    }
}