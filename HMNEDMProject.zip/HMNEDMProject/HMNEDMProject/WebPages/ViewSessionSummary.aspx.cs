﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HMNEDMProject.WebPages
{
    public partial class ViewSessionSummary : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            String userFName = (String)Session["UserName"];
            PMWelcomeLabel.Text = "Welcome " + userFName + "!";

            HMNEDMProject.Common.DatabaseConnection dc = new HMNEDMProject.Common.DatabaseConnection();
            DataTable dt = new DataTable();
            String currSessID;
            currSessID = (String)Session["sessSummaryID"];

            // Session Details
            dt = dc.selectQuery("select * from output_sessionsummary where sessionid = '" + currSessID + "' ");
            lvSessionSummary1.DataSource = dt;
            lvSessionSummary1.DataBind();

            // Session Count Details
            dt = dc.selectQuery("select * from output_session_count osc, site_location sl where osc.sessionid = '" + currSessID + "' and osc.site_id = sl.siteid ");
            lvSessionCounts.DataSource = dt;
            lvSessionCounts.DataBind();

            // Session Details 3
            dt = dc.selectQuery("select * from output2_report where sessionid = '" + currSessID + "' ");
            lvSessSumm3.DataSource = dt;
            lvSessSumm3.DataBind();
        }

        protected void lBtnPMLogout_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("Login.aspx", false);
        }
    }
}