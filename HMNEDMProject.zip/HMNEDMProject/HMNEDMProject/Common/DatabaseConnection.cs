﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

namespace HMNEDMProject.Common
{
    public class DatabaseConnection
    {
        public OracleConnection createConnection(String dataSource, String uName, String pWord)
        {
            string oradb = "Data Source=" + dataSource + ";User Id=" + uName +
                                ";Password=" + pWord + ";";
            OracleConnection conn = new OracleConnection(oradb);  // C#
            conn.Open();
            return conn;
        }
        public DataTable selectQuery(String selQuery)
        {
            DataTable dt  = new DataTable();
            OracleConnection aConn = new OracleConnection();
            try
            {
                aConn = createConnection("MyDB", "spartandb", "sgE/XV3Mx");
                OracleCommand cmd = new OracleCommand(selQuery, aConn);
                cmd.CommandType = CommandType.Text;
                //OracleDataReader dr = cmd.ExecuteReader();
                OracleDataAdapter da = new OracleDataAdapter(cmd);
                OracleCommandBuilder cb = new OracleCommandBuilder(da);
                DataSet ds = new DataSet();
                da.Fill(ds);
                dt = ds.Tables[0];
                return dt;
            }
            catch(Exception e)
            {
                Console.WriteLine(e.StackTrace);
                return dt;
            }
            finally
            {
                aConn.Close();
            }
        }

        public String insertIntoSession(String sessDesc, String sessLocID, DateTime sessDate)
        {
            int RETURN_VALUE_BUFFER_SIZE = 32767;
            OracleConnection conn = new OracleConnection();
            conn = createConnection("MyDB", "spartandb", "sgE/XV3Mx");
            OracleCommand cmd = new OracleCommand();
            String bval = "-1";
            try
            {
                // Call Procedure
                cmd.Connection = conn;
                cmd.CommandText = "spartandb.insert_session_func";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("returnVal", OracleDbType.Varchar2, RETURN_VALUE_BUFFER_SIZE);
                cmd.Parameters["returnVal"].Direction = ParameterDirection.ReturnValue;
                
                cmd.Parameters.Add("p_sessiondesc", OracleDbType.Varchar2);
                cmd.Parameters["p_sessiondesc"].Value = sessDesc;

                cmd.Parameters.Add("p_siteid", OracleDbType.Varchar2);
                cmd.Parameters["p_siteid"].Value = sessLocID;

                cmd.Parameters.Add("p_sessionDate", OracleDbType.Date);
                cmd.Parameters["p_sessionDate"].Value = sessDate;

                cmd.ExecuteNonQuery();
                bval = cmd.Parameters["returnVal"].Value.ToString();
                return bval;
            }
            catch (Exception e)
            {
                // deal with exception 
                Console.WriteLine(e.StackTrace);
                return bval;
            }
            finally
            {
                cmd.Dispose();
                conn.Close();
                conn.Dispose();
            }
        }
        public void myTry()
        {

            DataTable dTable = new DataTable();
            try
            {
                selectQuery("select * from users");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
            }
        }
        public void insertIntoOutputTable(String sessionID)
        {
            //int RETURN_VALUE_BUFFER_SIZE = 32767;
            OracleConnection conn = new OracleConnection();
            conn = createConnection("MyDB", "spartandb", "sgE/XV3Mx");
            OracleCommand cmd = new OracleCommand();
            try
            {
                // Call Procedure
                cmd.Connection = conn;
                cmd.CommandText = "spartandb.sessionSummaryHD";
                cmd.CommandType = CommandType.StoredProcedure;

                //cmd.Parameters.Add("returnVal", OracleDbType.Varchar2, RETURN_VALUE_BUFFER_SIZE);
                //cmd.Parameters["returnVal"].Direction = ParameterDirection.ReturnValue;

                cmd.Parameters.Add("p_sessionID", OracleDbType.Varchar2);
                cmd.Parameters["p_sessionID"].Value = sessionID;

                cmd.ExecuteNonQuery();
                //bval = cmd.Parameters["returnVal"].Value.ToString();
                //return bval;
            }
            catch (Exception e)
            {
                // deal with exception 
                Console.WriteLine(e.StackTrace);
            }
            finally
            {
                cmd.Dispose();
                conn.Close();
                conn.Dispose();
            }
        }
        public String validateUser(String uName, String pWord)
        {
            int RETURN_VALUE_BUFFER_SIZE = 32767;
            OracleConnection conn = new OracleConnection();
            conn = createConnection("MyDB", "spartandb", "sgE/XV3Mx");
            OracleCommand cmd = new OracleCommand();
            String bval = "-1";
            try
            {
                // Call Procedure
                cmd.Connection = conn;
                cmd.CommandText = "spartandb.validateUser";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("returnVal", OracleDbType.Varchar2, RETURN_VALUE_BUFFER_SIZE);
                cmd.Parameters["returnVal"].Direction = ParameterDirection.ReturnValue;

                cmd.Parameters.Add("uName", OracleDbType.Varchar2);
                cmd.Parameters["uName"].Value = uName;

                cmd.Parameters.Add("userPWord", OracleDbType.Varchar2);
                cmd.Parameters["userPWord"].Value = pWord;

                cmd.ExecuteNonQuery();
                bval = cmd.Parameters["returnVal"].Value.ToString();
                return bval;
            }
            catch (Exception e)
            {
                // deal with exception 
                Console.WriteLine(e.StackTrace);
                return "-1";
            }
            finally
            {
                cmd.Dispose();
                conn.Close();
                conn.Dispose();
            }
        }

        public void InsertNewMemberData(String mEmail, String mFName, String mMName, String mLName, String mStreet, String mCity, String mState, String mType, String mPhoneNo, String mSSN, String mHrlyWage)
        {
            OracleConnection conn = new OracleConnection();
            conn = createConnection("MyDB", "spartandb", "sgE/XV3Mx");
            OracleCommand cmd = new OracleCommand();

            try
            {
                // Call Procedure
                cmd.Connection = conn;
                cmd.CommandText = "spartandb.insert_members";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("p_email_id", OracleDbType.Varchar2);
                cmd.Parameters["p_email_id"].Value = mEmail;

                cmd.Parameters.Add("p_first_name", OracleDbType.Varchar2);
                cmd.Parameters["p_first_name"].Value = mFName;

                cmd.Parameters.Add("p_middle_name", OracleDbType.Varchar2);
                cmd.Parameters["p_middle_name"].Value = mMName;

                cmd.Parameters.Add("p_last_name", OracleDbType.Varchar2);
                cmd.Parameters["p_last_name"].Value = mLName;

                cmd.Parameters.Add("p_street", OracleDbType.Varchar2);
                cmd.Parameters["p_street"].Value = mStreet;

                cmd.Parameters.Add("p_city", OracleDbType.Varchar2);
                cmd.Parameters["p_city"].Value = mCity;

                cmd.Parameters.Add("p_state", OracleDbType.Varchar2);
                cmd.Parameters["p_state"].Value = mState;

                cmd.Parameters.Add("p_mem_type", OracleDbType.Varchar2);
                cmd.Parameters["p_mem_type"].Value = mType;

                cmd.Parameters.Add("p_phone_num", OracleDbType.Long);
                cmd.Parameters["p_phone_num"].Value = Int64.Parse(mPhoneNo);

                cmd.Parameters.Add("p_mem_SSN", OracleDbType.Long);
                cmd.Parameters["p_mem_SSN"].Value = Int64.Parse(mPhoneNo);

                cmd.Parameters.Add("p_mem_Hrlywage", OracleDbType.Long);
                cmd.Parameters["p_mem_Hrlywage"].Value = Int64.Parse(mPhoneNo);

                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                // deal with exception 
                Console.WriteLine(e.StackTrace);
            }
            finally
            {
                cmd.Dispose();
                conn.Close();
                conn.Dispose();
            }
        }
        public void getSessionData(String sessID)
        {
            OracleConnection conn = new OracleConnection();
            conn = createConnection("MyDB", "spartandb", "sgE/XV3Mx");
            OracleCommand cmd = new OracleCommand();

            try
            {
                cmd.Connection = conn;
                cmd.CommandText = "spartandb.xyz";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("sessID", OracleDbType.Varchar2);
                cmd.Parameters["sessID"].Value = sessID;
                cmd.ExecuteNonQuery();

            }
            catch (Exception e)
            {
                // deal with exception 
                Console.WriteLine(e.StackTrace);
            }
            finally
            {
                cmd.Dispose();
                conn.Close();
                conn.Dispose();
            }
        }

        public string getTaskID(String SessID, String task_type)
        {
            OracleConnection conn = new OracleConnection();
            conn = createConnection("MyDB", "spartandb", "sgE/XV3Mx");
            OracleCommand cmd = new OracleCommand();
            String returnvalue;

            try
            {
                cmd.Connection = conn;
                cmd.CommandText = "Select task_id from TASK WHERE sessionid = '" + SessID + "' AND task_type ='" + task_type +"'";
                cmd.CommandType = CommandType.Text;


                returnvalue = cmd.ExecuteScalar().ToString();
                return returnvalue;
                
            }
            catch (Exception e)
            {
                // deal with exception 
                Console.WriteLine(e.StackTrace);
                returnvalue = "null";
                return returnvalue;
            }
            finally
            {
                cmd.Dispose();
                conn.Close();
                conn.Dispose();
            }
            
            //throw new NotImplementedException();
        }

        internal DataTable PopulateSessionData(string currSessID)
        {

            OracleConnection conn = new OracleConnection();
            conn = createConnection("MyDB", "spartandb", "sgE/XV3Mx");
            OracleCommand cmd = new OracleCommand();
            DataTable dt = new DataTable();
            try
            {
                cmd.Connection = conn;
                cmd.CommandText = "spartandb.xyz";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("sessID", OracleDbType.Varchar2);
                cmd.Parameters["sessID"].Value = currSessID;
                cmd.ExecuteNonQuery();
                return dt;
            }
            catch (Exception e)
            {
                // deal with exception 
                Console.WriteLine(e.StackTrace);
                return dt;
            }
            finally
            {
                cmd.Dispose();
                conn.Close();
                conn.Dispose();
            }
            //throw new NotImplementedException();
        }

        internal void insertIntoTask(String SessID, String tasktype, String taskstarttime, String taskendtime )
        {
            OracleConnection conn = new OracleConnection();
            conn = createConnection("MyDB", "spartandb", "sgE/XV3Mx");
            OracleCommand cmd = new OracleCommand();

            OracleTimeStamp st = OracleTimeStamp.Parse(taskstarttime);
            OracleTimeStamp et = OracleTimeStamp.Parse(taskendtime);

            try
            {
                cmd.Connection = conn;
                cmd.CommandText = "spartandb.insert_task";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("p_sessionId", OracleDbType.Varchar2);
                cmd.Parameters["p_sessionId"].Value = SessID;

                cmd.Parameters.Add("p_startTime", OracleDbType.TimeStamp);
                cmd.Parameters["p_startTime"].Value = st;

                cmd.Parameters.Add("p_endTime", OracleDbType.TimeStamp);
                cmd.Parameters["p_endTime"].Value = et;

                cmd.Parameters.Add("p_taskType", OracleDbType.Varchar2);
                cmd.Parameters["p_taskType"].Value = tasktype;

                cmd.ExecuteNonQuery();
            }

            catch (Exception e)
            {
                // deal with exception 
                Console.WriteLine(e.StackTrace);
            }
            finally
            {
                cmd.Dispose();
                conn.Close();
                conn.Dispose();
            }
            //throw new NotImplementedException();
        }

        public String CalculateTime(String hr, String min, String dn)
        {
            String tasktime, taskdatemon, taskdateday, taskdateyr;
           // long temphr;
            taskdatemon = DateTime.Now.Month.ToString();
            taskdateday = DateTime.Now.Day.ToString();
            taskdateyr = DateTime.Now.Year.ToString();

          //  if (dn.Equals("am"))
          //  {
          //      temphr = 24 - Int32.Parse(hr);
          //      hr = temphr.ToString();
          //  }

            if(taskdatemon.Equals("1"))
            {
                taskdatemon = "JAN";
            }

            if (taskdatemon.Equals("2"))
            {
                taskdatemon = "FEB";
            }

            if (taskdatemon.Equals("3"))
            {
                taskdatemon = "MAR";
            }

            if (taskdatemon.Equals("4"))
            {
                taskdatemon = "APR";
            }

            if (taskdatemon.Equals("5"))
            {
                taskdatemon = "MAY";
            }

            if (taskdatemon.Equals("6"))
            {
                taskdatemon = "JUN";
            }

            if (taskdatemon.Equals("7"))
            {
                taskdatemon = "JUL";
            }

            if (taskdatemon.Equals("8"))
            {
                taskdatemon = "AUG";
            }

            if (taskdatemon.Equals("9"))
            {
                taskdatemon = "SEP";
            }

            if (taskdatemon.Equals("10"))
            {
                taskdatemon = "OCT";
            }

            if (taskdatemon.Equals("11"))
            {
                taskdatemon = "NOV";
            }

            if (taskdatemon.Equals("12"))
            {
                taskdatemon = "DEC";
            }

            tasktime = taskdateday + "/" + taskdatemon + "/" + taskdateyr + " " + hr + ":" + min + ":" + "00" + dn;
            
            return tasktime;
        }

        internal void updateTask(string currTaskID, string task_edtime)
        {
            OracleConnection conn = new OracleConnection();
            conn = createConnection("MyDB", "spartandb", "sgE/XV3Mx");
            OracleCommand cmd = new OracleCommand();

            try
            {
                cmd.Connection = conn;
                cmd.CommandText = "UPDATE TASK SET task_end_time = " + task_edtime + " WHERE task_id = '" + currTaskID + "'";
                cmd.CommandType = CommandType.Text;

            }

            catch (Exception e)
            {
                // deal with exception 
                Console.WriteLine(e.StackTrace);
               
            }
            finally
            {
                cmd.Dispose();
                conn.Close();
                conn.Dispose();
            }
            //throw new NotImplementedException();
        }

        public void generateSessionCounts(string sessID)
        {
            OracleConnection conn = new OracleConnection();
            conn = createConnection("MyDB", "spartandb", "sgE/XV3Mx");
            OracleCommand cmd = new OracleCommand();
            try
            {
                // Call Procedure
                cmd.Connection = conn;
                cmd.CommandText = "spartandb.countspecies";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("p_sessionID", OracleDbType.Varchar2);
                cmd.Parameters["p_sessionID"].Value = sessID;

                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                // deal with exception 
                Console.WriteLine(e.StackTrace);
            }
            finally
            {
                cmd.Dispose();
                conn.Close();
                conn.Dispose();
            }
        }

        public void generateSessionSummary(string sessID)
        {
            OracleConnection conn = new OracleConnection();
            conn = createConnection("MyDB", "spartandb", "sgE/XV3Mx");
            OracleCommand cmd = new OracleCommand();
            try
            {
                // Call Procedure 
                cmd.Connection = conn;
                cmd.CommandText = "spartandb.output_sessionsummaryhd";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("p_sessionID", OracleDbType.Varchar2);
                cmd.Parameters["p_sessionID"].Value = sessID;

                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                // deal with exception 
                Console.WriteLine(e.StackTrace);
            }
            finally
            {
                cmd.Dispose();
                conn.Close();
                conn.Dispose();
            }
        }

        public void InsertIntoTrapping()
        {
            //throw new NotImplementedException();
        }

        internal void InsertIntoTrapping(String taskID, String trapchk, Int32 escapecnt, Int32 hrno, Int32 visitncap, String endtime)
        {
            OracleConnection conn = new OracleConnection();
            conn = createConnection("MyDB", "spartandb", "sgE/XV3Mx");
            OracleCommand cmd = new OracleCommand();

            OracleTimeStamp et = OracleTimeStamp.Parse(endtime);
            try
            {
                cmd.Connection = conn;
                cmd.CommandText = "spartandb.insert_trap";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("p_ttaskid", OracleDbType.Varchar2);
                cmd.Parameters["p_ttaskid"].Value = taskID;

                cmd.Parameters.Add("p_trapcheck", OracleDbType.Varchar2);
                cmd.Parameters["p_trapcheck"].Value = trapchk;

                cmd.Parameters.Add("p_escapecount", OracleDbType.Int32);
                cmd.Parameters["p_escapecount"].Value = escapecnt;

                cmd.Parameters.Add("p_hournum", OracleDbType.Int32);
                cmd.Parameters["p_hournum"].Value = hrno;

                cmd.Parameters.Add("p_visitncap", OracleDbType.Int32);
                cmd.Parameters["p_visitncap"].Value = visitncap;

                cmd.Parameters.Add("p_task_end_time", OracleDbType.TimeStamp);
                cmd.Parameters["p_task_end_time"].Value = et;

                cmd.ExecuteNonQuery();
            }

            catch (Exception e)
            {
                // deal with exception 
                Console.WriteLine(e.StackTrace);

            }
            finally
            {
                cmd.Dispose();
                conn.Close();
                conn.Dispose();
            }
            
            //throw new NotImplementedException();
        }
        public String insertTeam(String sessID, String teamName, String locID)
        {
            int RETURN_VALUE_BUFFER_SIZE = 32767;
            OracleConnection conn = new OracleConnection();
            conn = createConnection("MyDB", "spartandb", "sgE/XV3Mx");
            OracleCommand cmd = new OracleCommand();
            String bval = "-1";
            try
            {
                // Call Procedure
                cmd.Connection = conn;
                cmd.CommandText = "spartandb.insert_team";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("returnVal", OracleDbType.Varchar2, RETURN_VALUE_BUFFER_SIZE);
                cmd.Parameters["returnVal"].Direction = ParameterDirection.ReturnValue;

                cmd.Parameters.Add("p_sessionid", OracleDbType.Varchar2);
                cmd.Parameters["p_sessionid"].Value = sessID;

                cmd.Parameters.Add("p_team_name", OracleDbType.Varchar2);
                cmd.Parameters["p_team_name"].Value = teamName;

                cmd.Parameters.Add("p_location", OracleDbType.Varchar2);
                cmd.Parameters["p_location"].Value = locID;

                cmd.ExecuteNonQuery();
                bval = cmd.Parameters["returnVal"].Value.ToString();
                return bval;
            }
            catch (Exception e)
            {
                // deal with exception 
                Console.WriteLine(e.StackTrace);
                return bval;
            }
            finally
            {
                cmd.Dispose();
                conn.Close();
                conn.Dispose();
            }
        }
        public void insertTeamDetails(String teamID, String memID, String startTime, String endTime)
        {
            //int RETURN_VALUE_BUFFER_SIZE = 32767;
            OracleConnection conn = new OracleConnection();
            conn = createConnection("MyDB", "spartandb", "sgE/XV3Mx");
            OracleCommand cmd = new OracleCommand();
            //String bval = "-1";
            try
            {
                // Call Procedure
                cmd.Connection = conn;
                cmd.CommandText = "spartandb.insert_teamDetails";
                cmd.CommandType = CommandType.StoredProcedure;

                //cmd.Parameters.Add("returnVal", OracleDbType.Varchar2, RETURN_VALUE_BUFFER_SIZE);
                //cmd.Parameters["returnVal"].Direction = ParameterDirection.ReturnValue;

                cmd.Parameters.Add("p_teamID", OracleDbType.Varchar2);
                cmd.Parameters["p_teamID"].Value = teamID;

                cmd.Parameters.Add("p_memID", OracleDbType.Varchar2);
                cmd.Parameters["p_memID"].Value = memID;

                OracleTimeStamp ots = new OracleTimeStamp(); 
                ots = OracleTimeStamp.Parse(startTime);
                
                cmd.Parameters.Add("p_arrivalTime", OracleDbType.TimeStamp);
                cmd.Parameters["p_arrivalTime"].Value = ots;

                ots = OracleTimeStamp.Parse(endTime);
                cmd.Parameters.Add("p_exittime", OracleDbType.TimeStamp);
                cmd.Parameters["p_exittime"].Value = ots;

                cmd.ExecuteNonQuery();
                //bval = cmd.Parameters["returnVal"].Value.ToString();
                //return bval;
            }
            catch (Exception e)
            {
                // deal with exception 
                Console.WriteLine(e.StackTrace);
                //return bval;
            }
            finally
            {
                cmd.Dispose();
                conn.Close();
                conn.Dispose();
            }
        }

        public void InsertHummingbirdData(String HOldBandNumber, String HBandNumber, String HCurrTaskID,
                                          String HTarsus, String HSize, String HSpecies, String HSex, Int32 HAge,
                                          String HGorColor, Int32 HGorCount, String HHeadGCount,
                                          String HGrooves, String HBuffy, String HPriWidth, String HWingTail,
                                          String HTailCent, String HTailMid, String HTailOut, String HTailMeas,
                                          String HWingCd, String HCulmen, String HPollenColor, String HPollenLocation,
                                          String HFat, String HCPBreed, String HGorget, String HHeadMolt, String HBodyMolt,
                                          String HPrimMolt, String HSecMolt, String HTailMolt, Int32 HWeight,
                                          String HFeatherCollected, String HSampleCollected, String HDayRecap,
                                          String HComment, String HBandStatus, String HBirdRecordID,
                                          String HBandingTime, String HPhotosTaken)
        {
            OracleConnection conn = new OracleConnection();
            conn = createConnection("MyDB", "spartandb", "sgE/XV3Mx");
            OracleCommand cmd = new OracleCommand();

            try
            {
                // Call Procedure
                cmd.Connection = conn;
                cmd.CommandText = "spartandb.Insert_HummingBirdRecord";
                cmd.CommandType = CommandType.StoredProcedure;

                OracleTimeStamp ots = new OracleTimeStamp();
                ots = OracleTimeStamp.Parse(HBandingTime);

                cmd.Parameters.Add("OldBandNum", OracleDbType.Varchar2);
                cmd.Parameters["OldBandNum"].Value = HOldBandNumber;

                cmd.Parameters.Add("newBandNum", OracleDbType.Varchar2);
                cmd.Parameters["newBandNum"].Value = HBandNumber;

                cmd.Parameters.Add("BTaskID", OracleDbType.Varchar2);
                cmd.Parameters["BTaskID"].Value = HCurrTaskID;

                cmd.Parameters.Add("Tarsus", OracleDbType.Varchar2);
                cmd.Parameters["Tarsus"].Value = HTarsus;

                cmd.Parameters.Add("Size_bird", OracleDbType.Varchar2);
                cmd.Parameters["Size_bird"].Value = HSize;

                cmd.Parameters.Add("SpeciesID", OracleDbType.Varchar2);
                cmd.Parameters["SpeciesID"].Value = HSpecies;

                cmd.Parameters.Add("Sex", OracleDbType.Varchar2);
                cmd.Parameters["Sex"].Value = HSex;

                cmd.Parameters.Add("Age", OracleDbType.Int32);
                cmd.Parameters["Age"].Value = HAge;

                cmd.Parameters.Add("GorColor", OracleDbType.Varchar2);
                cmd.Parameters["GorColor"].Value = HGorColor;

                cmd.Parameters.Add("GorCountPercent", OracleDbType.Int32);
                cmd.Parameters["GorCountPercent"].Value = HGorCount;

                cmd.Parameters.Add("HeadGCnt", OracleDbType.Varchar2);
                cmd.Parameters["HeadGCnt"].Value = HHeadGCount;

                cmd.Parameters.Add("Grooves", OracleDbType.Varchar2);
                cmd.Parameters["Grooves"].Value = HGrooves;

                cmd.Parameters.Add("Buffy", OracleDbType.Varchar2);
                cmd.Parameters["Buffy"].Value = HBuffy;

                cmd.Parameters.Add("PriWidth", OracleDbType.Varchar2);
                cmd.Parameters["PriWidth"].Value = HPriWidth;

                cmd.Parameters.Add("WngTailTrait", OracleDbType.Varchar2);
                cmd.Parameters["WngTailTrait"].Value = HWingTail;

                cmd.Parameters.Add("TailCent", OracleDbType.Varchar2);
                cmd.Parameters["TailCent"].Value = HTailCent;

                cmd.Parameters.Add("TailMid", OracleDbType.Varchar2);
                cmd.Parameters["TailMid"].Value = HTailMid;

                cmd.Parameters.Add("TailOut", OracleDbType.Varchar2);
                cmd.Parameters["TailOut"].Value = HTailOut;

                cmd.Parameters.Add("TailMeas", OracleDbType.Varchar2);
                cmd.Parameters["TailMeas"].Value = HTailMeas;

                cmd.Parameters.Add("WingCd", OracleDbType.Varchar2);
                cmd.Parameters["WingCd"].Value = HWingCd;

                cmd.Parameters.Add("Culmen", OracleDbType.Varchar2);
                cmd.Parameters["Culmen"].Value = HCulmen;

                cmd.Parameters.Add("PollenColor", OracleDbType.Varchar2);
                cmd.Parameters["PollenColor"].Value = HPollenColor;

                cmd.Parameters.Add("PollenLocation", OracleDbType.Varchar2);
                cmd.Parameters["PollenLocation"].Value = HPollenLocation;

                cmd.Parameters.Add("Fat", OracleDbType.Varchar2);
                cmd.Parameters["Fat"].Value = HFat;

                cmd.Parameters.Add("CPBreed", OracleDbType.Varchar2);
                cmd.Parameters["CPBreed"].Value = HCPBreed;

                cmd.Parameters.Add("Gorget", OracleDbType.Varchar2);
                cmd.Parameters["Gorget"].Value = HGorget;

                cmd.Parameters.Add("headmolt", OracleDbType.Varchar2);
                cmd.Parameters["headmolt"].Value = HHeadMolt;

                cmd.Parameters.Add("BodyMolt", OracleDbType.Varchar2);
                cmd.Parameters["BodyMolt"].Value = HBodyMolt;

                cmd.Parameters.Add("PrimaryMolt", OracleDbType.Varchar2);
                cmd.Parameters["PrimaryMolt"].Value = HPrimMolt;

                cmd.Parameters.Add("SecMolt", OracleDbType.Varchar2);
                cmd.Parameters["SecMolt"].Value = HSecMolt;

                cmd.Parameters.Add("TailMolt", OracleDbType.Varchar2);
                cmd.Parameters["TailMolt"].Value = HTailMolt;

                cmd.Parameters.Add("Weight", OracleDbType.Int32);
                cmd.Parameters["Weight"].Value = HWeight;

                cmd.Parameters.Add("Feather_Collect", OracleDbType.Varchar2);
                cmd.Parameters["Feather_Collect"].Value = HFeatherCollected;

                cmd.Parameters.Add("Samp_Collected", OracleDbType.Varchar2);
                cmd.Parameters["Samp_Collected"].Value = HSampleCollected;

                cmd.Parameters.Add("Day_Rec_Num", OracleDbType.Varchar2);
                cmd.Parameters["Day_Rec_Num"].Value = HDayRecap;

                cmd.Parameters.Add("Comments", OracleDbType.Varchar2);
                cmd.Parameters["Comments"].Value = HComment;

                cmd.Parameters.Add("band_status_code", OracleDbType.Varchar2);
                cmd.Parameters["band_status_code"].Value = HBandStatus;

                cmd.Parameters.Add("unqBirdRecordID", OracleDbType.Varchar2);
                cmd.Parameters["unqBirdRecordID"].Value = HBirdRecordID;

                cmd.Parameters.Add("bandingTime", OracleDbType.TimeStamp);
                cmd.Parameters["bandingTime"].Value = ots;

                cmd.Parameters.Add("photoTaken", OracleDbType.Varchar2);
                cmd.Parameters["photoTaken"].Value = HPhotosTaken;

                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                // deal with exception 
                Console.WriteLine(e.StackTrace);
            }
            finally
            {
                cmd.Dispose();
                conn.Close();
                conn.Dispose();
            }
        }

        public void InsertIntoBanding(String HcurrTaskID, String HLeadBanderID, Int32 HNumBirdsBanded)
        {
            OracleConnection conn = new OracleConnection();
            conn = createConnection("MyDB", "spartandb", "sgE/XV3Mx");
            OracleCommand cmd = new OracleCommand();

            try
            {
                // Call Procedure
                cmd.Connection = conn;
                cmd.CommandText = "spartandb.insert_banding";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("p_btaskid", OracleDbType.Varchar2);
                cmd.Parameters["p_btaskid"].Value = HcurrTaskID;

                cmd.Parameters.Add("p_banderid", OracleDbType.Varchar2);
                cmd.Parameters["p_banderid"].Value = HLeadBanderID;

                cmd.Parameters.Add("p_numbirdsbanded", OracleDbType.Varchar2);
                cmd.Parameters["p_numbirdsbanded"].Value = HNumBirdsBanded;               

                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                // deal with exception 
                Console.WriteLine(e.StackTrace);
            }
            finally
            {
                cmd.Dispose();
                conn.Close();
                conn.Dispose();
            }
        }
    }
}